# Revision Map — SDH-PPO Paper

**Draft:** `SDN-IoT.docx` (SDH-PPO Driven Resource Orchestration for IoT-Aware Multi-Tenant Network Slicing in Microservices-Based SDN)
**Sumber revisi:** `Cek_Draft_Paper_-_Draft_SDH-PPOv2_5__21082026_.docx` (24 poin) + 7 temuan tambahan hasil audit draft
**Repo:** `github.com/adaptivenetworklab/sdn-iot`

**Legenda kolom Sumber Jawaban:**
`CC` = Claude Code di repo · `NLM` = NotebookLM (sumber referensi) · `MAN` = manual/keputusan penulis · `EXP` = butuh eksperimen ulang

---

## Ringkasan status

| Kluster | Jumlah item | Effort | Blocking? |
|---|---|---|---|
| A. Metodologi | 5 | Berat | Ya — tanpa ini paper tidak bisa dievaluasi |
| B. Kontradiksi angka | 3 | Rendah | Ya — alasan penolakan instan |
| C. Rigor eksperimen | 7 | Sedang–berat | Ya |
| D. Referensi | 5 | Rendah | Tidak, tapi merusak kredibilitas |
| E. Presentasi | 2 | Rendah–sedang | Tidak |
| X. Temuan tambahan | 7 | Rendah | Sebagian ya (X2, X3) |
| **Total** | **29** | | |

---

## Kluster A — Metodologi (Section III)

Semua klaim kontribusi di Section I tidak punya pasangan deskripsi di Section III. Ini akar masalahnya.

| ID | Isu | Diklaim di | Harus ditulis di | Kondisi sekarang | Sumber jawaban | Status |
|---|---|---|---|---|---|---|
| A1 | **Hybrid action space** — "continuous bandwidth adjustment and discrete port selection" | Abstract, Intro | III.E | III.E hanya mendeskripsikan Actor yang memetakan state ke *continuous* action space. Tidak ada parameterized action space (mis. PADQN), tidak ada arsitektur | CC | ☐ |
| A2 | **Safety layer / mathematical security layer based on action predictions** | Kontribusi #2 (Intro), III.F ("safety layer"), IV.B | III.E atau subsection baru | Nol persamaan. Eq 1–15 semuanya komponen standar (PPO, GAE, WGAN-GP, z-score) | CC | ☐ |
| A3 | **Dueling Critic** | III.F ("duel layer"), IV.B ("Dueling Critic architecture") | III.E | Tidak pernah didefinisikan. Dueling itu konsep DQN; kalau dipakai di actor-critic PPO harus dijelaskan bagaimana critic dipecah jadi state-value dan advantage stream. *Catatan: reviewer menulis "hanya muncul di Kesimpulan", padahal sebenarnya di III.F dan akhir IV.B* | CC | ☐ |
| A4 | **EO-WGAN** — "Enhanced Optimization" tidak pernah didefinisikan | Abstract, Intro, IV.A | III.C | Eq 2–4 persis WGAN-GP standar (Gulrajani et al. 2017) yang tidak dikutip. **Bukti tambahan: Kesimpulan sendiri menulis "WGAN-GP-based data growth models", bukan EO-WGAN** → penamaan tidak konsisten di dalam paper | CC + MAN | ☐ |
| A5 | **37 state features** tidak dienumerasi | III.F (satu kalimat) | III.A / MDP formulation | State space tidak didefinisikan formal | CC | ☐ |

**Keputusan yang harus diambil dulu:** apakah A1/A2/A3 benar-benar ada di kode? Kalau ada → tulis deskripsinya. Kalau tidak → turunkan klaim di Abstract, Intro, dan Kesimpulan supaya konsisten. Jangan tulis metode yang tidak dijalankan.

---

## Kluster B — Kontradiksi angka (kerjakan pertama, murah)

| ID | Isu | Lokasi persis | Perbaikan | Sumber | Status |
|---|---|---|---|---|---|
| B1 | **Ambang SLA tidak seragam** | Tabel II (III.A): P1 `<10ms`, P2 `<150ms`, P4 `<10ms` · Fig. 4 caption + IV.A + IV.B: P1 `6ms`, P2 `7ms`, P4 `7ms` · IV.B paragraf hasil P4: `"10 ms threshold"` | Tentukan satu sumber kebenaran, seragamkan di 4 tempat. Gap terbesar: P2 150ms vs 7ms | CC + NLM | ☐ |
| B2 | **Arah klaim terbalik** | IV.B: *"recorded an overall error rate of 10.3%, which is 9.2 percentage points **higher** than the standard PPO and significantly **higher** than the DQN (48.9%), the DDQN (51.6%), and the static model (44.8%)"* | Ganti `higher` → `lower` di 3 tempat. **Angkanya sendiri sudah benar:** 19.5−10.3 = 9.2 pp; (19.5−10.3)/19.5 = 47.2%; (44.8−10.3)/44.8 = 77.0%; (48.9−10.3)/48.9 = 78.9%; (51.6−10.3)/51.6 = 80.0% | MAN | ☐ |
| B3 | **Port 3 hilang + sistem prioritas tidak didefinisikan** | III.A mendefinisikan Slice 3 (Smart Building), tapi hasil hanya memuat port 1, 2, 4 | Jelaskan ke mana port 3, atau tambahkan hasilnya. Sekalian definisikan pemetaan port → slice → priority level secara eksplisit | CC | ☐ |

---

## Kluster C — Rigor eksperimen

Sebagian besar jawabannya ada di repo, bukan hal yang perlu dieksperimen ulang. Kecuali C1.

| ID | Isu | Lokasi | Yang dibutuhkan | Sumber | Status |
|---|---|---|---|---|---|
| C1 | Tidak ada jumlah seed, confidence interval, uji signifikansi | Tabel V + seluruh IV.B | Semua angka terlihat hasil satu run. Klaim *"consistently outperforms"* tidak didukung. Minimal 5–10 seed + mean ± 95% CI, plus uji (Welch's t-test / Mann-Whitney) | CC lalu EXP | ☐ |
| C2 | Static heuristic baseline tidak didefinisikan | III.F, satu kalimat (`γ=0.99 over 2,000 steps` — γ untuk heuristik non-AI juga janggal) | Bagaimana ia mengalokasikan resource? Fixed policing rate? Round-robin? Tanpa ini "76.9% improvement" tidak bermakna | CC | ☐ |
| C3 | Detail implementasi DQN/DDQN hilang | III.F | ε-greedy schedule, target network update freq, replay buffer size, arsitektur. Kalau value-based dipaksa pakai protokol training PPO (2000 "epochs", batch 64), perbandingannya tidak adil | CC | ☐ |
| C4 | Tabel III nyaris kosong | III.F | Tambah: PPO clip ratio ε, GAE λ, entropy coefficient, value loss coef, jumlah layer + aktivasi + lebar, dan **seluruh hyperparameter GAN** (λ gradient penalty, n_critic, lr generator/critic, latent dim, batch, epoch GAN) | CC | ☐ |
| C5 | "2000 epochs" ambigu | III.F + Tabel III | Updates atau episodes? Artinya beda untuk DQN vs PPO. Sebutkan total environment steps supaya sebanding | CC | ☐ |
| C6 | Di mana training berjalan? | Tidak ada | Model Pi 5 + RAM, lokasi training (offline di PC?), runtime per epoch, dan apa persisnya yang jalan di Pi 5 saat deployment (inference only?). Klaim "physical testbed" justru butuh detail ini | CC + MAN | ☐ |
| C7 | Tidak ada ablation study + diskusi P2 (29.5%) dan trade-off konvergensi | Tidak ada | Ablation: −safety layer, −dueling critic, −EO-WGAN, −hybrid action. Plus diskusi kenapa P2 masih 29.5% dan kenapa konvergensi 2× lebih lambat itu dapat diterima | EXP + MAN | ☐ |

---

## Kluster D — Referensi

| ID | Isu | Detail terverifikasi | Aksi | Status |
|---|---|---|---|---|
| D1 | 4 pasang duplikat | `[1]`=`[26]` Wijethilaka & Liyanage (COMST) · `[13]`=`[29]` Xu & Yu (Computer Networks) · `[16]`=`[32]` Sittakul et al. (JNCA) · `[37]`=`[38]` Zhang et al. (ICC Workshops) | Hapus duplikat, renumber. 44 → 40 entri unik | ☐ |
| D2 | Sitasi Holscher salah | II.A: *"Holscher integrated microservice orchestration logic... via switches[21]"*. `[21]` = Fernandez et al. Holscher = `[31]` | Ganti ke `[31]` | ☐ |
| D3 | Sitasi blockchain salah | II.A: *"...AI and secured by blockchain[21]"*. Harusnya Zhang et al. = `[37]`/`[38]`. Kalimat berikutnya di paragraf sama sudah benar pakai `[38]` → jelas typo | Ganti ke `[37]` | ☐ |
| D4 | Sitasi WGAN salah | III.C: klaim stabilisasi Arjovsky disitasi ke `[44]` = C. Tan, *"Comparative Study of RL Performance Based on PPO and DQN"* — tidak ada kaitan dengan WGAN | Tambah 2 referensi baru: Arjovsky et al., *Wasserstein GAN*, ICML 2017 (`dl.acm.org/doi/10.5555/3305381.3305404`) dan Gulrajani et al., *Improved Training of Wasserstein GANs*, NeurIPS 2017 (`papers.nips.cc/paper_files/paper/2017/hash/892c3b1c6dccd52936e27cbd0ff683d6-Abstract.html`). Kutip Gulrajani di Eq 2–4 | ☐ |
| D5 | `[39]` tidak lengkap | T. Mai, H. Yao, N. Zhang, W. He, D. Guo, M. Guizani, *"Transfer Reinforcement Learning aided Distributed Network Slicing Optimization in Industrial IoT"* — tanpa venue, tahun, DOI | Lengkapi metadata (kemungkinan IEEE TII) | ☐ |

---

## Kluster E — Presentasi

| ID | Isu | Detail | Sumber | Status |
|---|---|---|---|---|
| E1 | Tabel research gap di Related Work | Tabel I sudah ada tapi hanya centang/strip. Reviewer minta tabel yang menyampaikan **kelebihan dan keterbatasan** tiap studi, ditutup dengan baris yang memunculkan keunggulan metode yang diajukan | NLM | ☐ |
| E2 | Resolusi gambar | Audit file media di `.docx`: `image1` 495×929 @96dpi (Fig.1) · `image2` 732×341 @96dpi (Fig.2) · `image3` 572×478 @96dpi (**Fig.3, yang dikeluhkan**) · `image4` 1191×1059 @220dpi (Fig.4) · `image5–8` ~950×300 @96dpi (Fig.5–8). **Bukan cuma Fig.3 — semua kecuali Fig.4 di 96 dpi, dan Fig.4 pun masih di bawah 300 dpi standar IEEE.** Regenerate semua plot sebagai vektor (PDF/EPS/SVG) atau raster ≥300 dpi | CC | ☐ |

---

## Kluster X — Temuan tambahan (di luar catatan reviewer)

| ID | Isu | Lokasi | Sumber | Status |
|---|---|---|---|---|
| X1 | **Cross-reference tabel salah** | III.F: *"As summarized in Table 2"* → maksudnya Tabel III. Awal Section IV: *"summarized in Table 3"* → maksudnya Tabel V. Penomoran Arab dan Romawi tercampur | MAN | ☐ |
| X2 | **Penomoran prioritas bertentangan dengan penomoran slice** | III.A: Slice 1 (Healthcare) = prioritas tertinggi. Tapi hasil menyebut healthcare sebagai **"Priority 4 (P4)"** dan P1 = DHT11 (smart building = best-effort). Pembaca akan bingung mana yang prioritas tinggi | CC + MAN | ☐ |
| X3 | **Reward function tidak cocok dengan klaim hasil** | Eq 10 hanya menghukum latency P4 (`Plat_p4`); Eq 8 hanya menghitung throughput port 2 (`RX_p2/T_p2`). Tapi IV.B mengklaim perbaikan signifikan di P1 dan P2. Perlu dijelaskan kenapa agen memperbaiki port yang tidak masuk reward, atau reward function di paper belum lengkap | CC | ☐ |
| X4 | **Struktur III.C / III.D salah tempat** | III.C "Augmentation" memuat Eq 5–6 (bandwidth utilization, packet drop) = logika *environment*. III.D "Pre-Processing" memuat Eq 7–11 (reward function, action formulation) = *MDP formulation*. Usulan restrukturisasi: `III.A Environment` → `III.B MDP Formulation (state/action/reward)` → `III.C Augmentation (EO-WGAN)` → `III.D Proposed Framework (hybrid actor, safety layer, dueling critic)` → `III.E Baselines & Experimental Setup` | MAN | ☐ |
| X5 | **Kalimat duplikat** | III.C: *"...even when the overlap between the distributions of real and synthetic data is minimal[44]. When the overlap between the distributions of real and synthetic data is small[44]."* Fragmen kedua sisa editing | MAN | ☐ |
| X6 | **Kualitas sumber ambang SLA lemah** | `[41]` Z. Gdali, *"Edge Computing vs Cloud: Latency Impact"*, Firecell = blog vendor. `[43]` Mu et al. *CoMEx* = paper RAN slicing, tidak berkaitan dengan SLA heart rate. `[23]` tanpa volume/halaman dari theaspd.com. Ambang SLA medis sebaiknya dari standar (IEEE 11073, 3GPP URLLC) atau literatur IoMT yang peer-reviewed | NLM | ☐ |
| X7 | **Typo huruf awal hilang (artefak drop cap) + format tabel** | *"hE Ongoing progress"* (Intro) · *"he proposed framework consists"* (III.E) · *"he resulting visualization"* (IV.A) · *"able V shows"* (IV.B). Tabel V baris `Static` punya sel kosong berlebih | MAN | ☐ |

---

## Urutan pengerjaan

### Tahap 1 — Kredibilitas cepat (1–2 hari, tanpa dependensi)
`B2` · `D1` · `D2` · `D3` · `D4` · `D5` · `X1` · `X5` · `X7`
Semuanya editorial. Tidak butuh repo, tidak butuh eksperimen. Selesaikan dulu supaya draft berikutnya tidak ditolak karena hal remeh.

### Tahap 2 — Ekstraksi ground truth dari repo (jalankan Claude Code)
`A1` · `A2` · `A3` · `A4` · `A5` · `B1` · `B3` · `C2` · `C3` · `C4` · `C5` · `C6` · `X2` · `X3` · `E2`
Output tahap ini menentukan bentuk tahap 3.

### Tahap 3 — Penulisan ulang Section III
`A1`–`A5` + `X4`. Paling berat. Bentuknya tergantung hasil tahap 2:
- Kalau hybrid/safety/dueling **ada di kode** → tulis deskripsi + persamaan formalnya
- Kalau **tidak ada** → turunkan klaim di Abstract, Intro, Kesimpulan, dan Tabel I (kolom "Hybrid/Action Space" untuk baris PROPOSE)

### Tahap 4 — Rigor + presentasi
`C1` (seeds/CI, kemungkinan butuh re-run) · `C7` (ablation) · `E1` (tabel research gap) · `X6` (sumber SLA)

---

## Tracking

Ubah `☐` jadi `☑` saat selesai. Catat keputusan penting (terutama hasil tahap 2 untuk A1–A4) di bawah ini supaya tidak hilang:

### Log keputusan

| Tanggal | Item | Keputusan | Alasan |
|---|---|---|---|
| | | | |
